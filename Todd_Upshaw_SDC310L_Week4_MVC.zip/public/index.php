<?php
require_once __DIR__ . "/../controllers/BudgetController.php";
$controller=new BudgetController();
$data=$controller->handleRequest();
require_once __DIR__ . "/../views/index.php";
