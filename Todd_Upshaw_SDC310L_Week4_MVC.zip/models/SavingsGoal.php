<?php
class SavingsGoal {
    public function __construct(private mysqli $db) {}

    public function all(): array {
        $rows=[]; $r=$this->db->query("SELECT * FROM savings_goals ORDER BY goal_id DESC");
        if($r) while($row=$r->fetch_assoc()) $rows[]=$row;
        return $rows;
    }

    public function create(string $name,float $target,float $current,string $date): bool {
        $s=$this->db->prepare("INSERT INTO savings_goals (goal_name,target_amount,current_amount,target_date) VALUES (?,?,?,?)");
        $s->bind_param("sdds",$name,$target,$current,$date); $ok=$s->execute(); $s->close(); return $ok;
    }

    public function delete(int $id): bool {
        $s=$this->db->prepare("DELETE FROM savings_goals WHERE goal_id=?");
        $s->bind_param("i",$id); $ok=$s->execute(); $s->close(); return $ok;
    }
}
