<?php
class Transaction {
    public function __construct(private mysqli $db) {}

    public function all(): array {
        $rows=[]; $r=$this->db->query("SELECT * FROM transactions ORDER BY transaction_date DESC, transaction_id DESC");
        if ($r) while($row=$r->fetch_assoc()) $rows[]=$row;
        return $rows;
    }

    public function find(int $id): ?array {
        $s=$this->db->prepare("SELECT * FROM transactions WHERE transaction_id=?");
        $s->bind_param("i",$id); $s->execute(); $r=$s->get_result();
        $row=$r->fetch_assoc() ?: null; $s->close(); return $row;
    }

    public function create(string $type,float $amount,string $category,string $date,string $description): bool {
        $s=$this->db->prepare("INSERT INTO transactions (transaction_type,amount,category,transaction_date,description) VALUES (?,?,?,?,?)");
        $s->bind_param("sdsss",$type,$amount,$category,$date,$description); $ok=$s->execute(); $s->close(); return $ok;
    }

    public function update(int $id,string $type,float $amount,string $category,string $date,string $description): bool {
        $s=$this->db->prepare("UPDATE transactions SET transaction_type=?,amount=?,category=?,transaction_date=?,description=? WHERE transaction_id=?");
        $s->bind_param("sdsssi",$type,$amount,$category,$date,$description,$id); $ok=$s->execute(); $s->close(); return $ok;
    }

    public function delete(int $id): bool {
        $s=$this->db->prepare("DELETE FROM transactions WHERE transaction_id=?");
        $s->bind_param("i",$id); $ok=$s->execute(); $s->close(); return $ok;
    }

    public function summary(): array {
        $income=0; $expenses=0;
        $r=$this->db->query("SELECT transaction_type,COALESCE(SUM(amount),0) total FROM transactions GROUP BY transaction_type");
        if($r) while($row=$r->fetch_assoc()) {
            if($row["transaction_type"]==="Income") $income=(float)$row["total"];
            if($row["transaction_type"]==="Expense") $expenses=(float)$row["total"];
        }
        return ["income"=>$income,"expenses"=>$expenses,"balance"=>$income-$expenses];
    }
}
