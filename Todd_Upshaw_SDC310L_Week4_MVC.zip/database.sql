CREATE DATABASE IF NOT EXISTS todd_budget_tracker DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE todd_budget_tracker;
CREATE TABLE IF NOT EXISTS transactions (
 transaction_id INT NOT NULL AUTO_INCREMENT, transaction_type VARCHAR(20) NOT NULL,
 amount DECIMAL(10,2) NOT NULL, category VARCHAR(100) NOT NULL,
 transaction_date DATE NOT NULL, description VARCHAR(255), PRIMARY KEY(transaction_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS savings_goals (
 goal_id INT NOT NULL AUTO_INCREMENT, goal_name VARCHAR(100) NOT NULL,
 target_amount DECIMAL(10,2) NOT NULL, current_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
 target_date DATE NOT NULL, PRIMARY KEY(goal_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
